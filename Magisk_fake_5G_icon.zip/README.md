# Fake 5G icon
### E7KMbb/AiSauce
[中文说明](https://github.com/E7KMbb/Fake_5G_icon/blob/master/README_zh.md)

### Introduction
Change the LTE and 4G icons in the status bar to 5G.

### Precautions
This module does not support in-depth custom ROMs that can be modified with themes (MIUI Flyme oneUI EMUI ColorOS FuntouchOS Nubiaui RedMagicOS)

Because this module is modified by the systemui.apk of the system, it will conflict with the module that also modifies the systemui.apk

### Link
* [GitHub](https://github.com/E7KMbb/Fake_5G_icon)

* [Donate](https://docs.qq.com/doc/DWVJKWVVDWURQZUZK?disableReturnList=1&_from=1)

* [TG](https://t.me/AiSauce)

### Updatelog
- v3.1 Join 5GE style
- <S>v3.0 Rewrite the script, realize automatic generation, add device detection</S>
- v2.2 Optimize the script and delete some extra files
- v2.1 Remove LG support,because it doesn't work